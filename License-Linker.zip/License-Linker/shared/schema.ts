import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, numeric, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  telegramUsername: text("telegram_username").notNull().unique(),
  telegramChatId: text("telegram_chat_id"),
  verified: boolean("verified").default(false),
  creditBalance: numeric("credit_balance", { precision: 12, scale: 2 }).default("0"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  telegramUsername: true,
  telegramChatId: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const transactionTypeEnum = pgEnum("transaction_type", ["topup", "purchase", "refund", "adjustment"]);
export const transactionSourceEnum = pgEnum("transaction_source", ["khqr", "crypto", "manual", "system"]);
export const transactionStatusEnum = pgEnum("transaction_status", ["completed", "pending", "failed"]);

export const creditTransactions = pgTable("credit_transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  balanceAfter: numeric("balance_after", { precision: 12, scale: 2 }).notNull(),
  type: text("type").notNull(), // topup, purchase, refund, adjustment
  source: text("source").notNull(), // khqr, crypto, manual, system
  status: text("status").notNull().default("completed"), // completed, pending, failed
  description: text("description"),
  orderId: varchar("order_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCreditTransactionSchema = createInsertSchema(creditTransactions).pick({
  userId: true,
  amount: true,
  balanceAfter: true,
  type: true,
  source: true,
  status: true,
  description: true,
  orderId: true,
});

export type InsertCreditTransaction = z.infer<typeof insertCreditTransactionSchema>;
export type CreditTransaction = typeof creditTransactions.$inferSelect;

export const orders = pgTable("orders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orderId: varchar("order_id").notNull().unique(),
  status: text("status").notNull().default("pending"), // pending, paid, confirmed, delivered, cancelled
  items: text("items").notNull(), // JSON string of items
  total: numeric("total", { precision: 12, scale: 2 }).notNull(),
  totalKHR: text("total_khr").notNull(),
  bankAccountName: text("bank_account_name").notNull(),
  phoneNumber: text("phone_number").notNull(),
  telegramUsername: text("telegram_username").notNull(),
  remark: text("remark"),
  telegramMessageId: text("telegram_message_id"),
  telegramChatId: text("telegram_chat_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertOrderSchema = createInsertSchema(orders).pick({
  orderId: true,
  status: true,
  items: true,
  total: true,
  totalKHR: true,
  bankAccountName: true,
  phoneNumber: true,
  telegramUsername: true,
  remark: true,
  telegramMessageId: true,
  telegramChatId: true,
});

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;

export const verificationSessions = pgTable("verification_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").notNull().unique(),
  code: varchar("code", { length: 6 }).notNull(),
  telegramUsername: text("telegram_username").notNull(),
  verified: boolean("verified").default(false),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertVerificationSessionSchema = createInsertSchema(verificationSessions).pick({
  sessionId: true,
  code: true,
  telegramUsername: true,
  verified: true,
  expiresAt: true,
});

export type InsertVerificationSession = z.infer<typeof insertVerificationSessionSchema>;
export type VerificationSession = typeof verificationSessions.$inferSelect;

export const productCategories = [
  "AI",
  "Streaming",
  "VPN",
  "Productivity",
  "Design",
  "Cloud",
  "Security",
  "Education",
  "Music",
  "Video",
  "Utilities",
] as const;

export type ProductCategory = (typeof productCategories)[number];

export interface Product {
  id: string;
  name: string;
  description: string;
  category: ProductCategory;
  price: number;
  devices: number | "Unlimited";
}

export interface CartItem {
  product: Product;
  quantity: number;
}
