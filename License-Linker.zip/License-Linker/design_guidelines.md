# Design Guidelines: Midnight Sapphire Theme

## Design Approach
**Midnight Sapphire**: A premium dark theme featuring deep navy gradients with teal accents, glassmorphism effects, and a sophisticated aesthetic designed for the Cambodian digital marketplace.

## Core Design Principles
- Deep, immersive dark navy backgrounds with subtle aurora gradients
- Glassmorphism cards with blur effects and translucent borders
- Teal accent colors for interactive elements and highlights
- Professional, luxurious feel that builds trust
- Dual currency display (USD and Khmer Riel) for local market

## Color Palette

### Primary Colors
- **Deep Navy**: #0a0e1a (background base)
- **Navy Mid**: #111827 (card backgrounds)
- **Navy Light**: #1e293b (elevated surfaces)

### Accent Colors
- **Teal Primary**: #14b8a6 (primary actions, highlights)
- **Teal Light**: #2dd4bf (hover states)
- **Teal Glow**: rgba(20, 184, 166, 0.3) (glow effects)

### Supporting Colors
- **Cyan Accent**: #22d3ee (secondary highlights)
- **Purple Subtle**: #8b5cf6 (category badges)
- **Amber Warm**: #fbbf24 (ratings, warnings)

### Text Colors
- **Primary Text**: #f1f5f9 (main content)
- **Secondary Text**: #94a3b8 (descriptions, labels)
- **Muted Text**: #64748b (less important info)

## Typography
- **Font Family**: Inter (primary), system fallbacks
- **Weights**: 400 (regular), 500 (medium), 600 (semibold), 700 (bold)
- **Hierarchy**:
  - Product titles: 18px semibold
  - Descriptions: 13px regular, muted
  - Prices: 20px bold
  - Labels: 12px medium

## Card Design (Glassmorphism)

### Product Cards
- Background: Semi-transparent navy with blur
- Border: 1px subtle teal/white gradient border
- Shadow: Soft teal glow on hover
- Border-radius: 16px (rounded-2xl)

### Structure
1. **Icon Section**: Centered product icon with colored background halo
2. **Content Section**: Product name, description, device count
3. **Price Section**: USD price prominent, KHR below
4. **Action Section**: Add to cart button with teal gradient

### Hover Effects
- Subtle lift (translateY -4px)
- Teal glow intensifies
- Border becomes more visible

## Layout System

### Spacing Scale
- **xs**: 4px (micro gaps)
- **sm**: 8px (tight spacing)
- **md**: 16px (standard padding)
- **lg**: 24px (section gaps)
- **xl**: 32px (major sections)

### Grid
- Desktop: 4 columns
- Tablet: 3 columns
- Mobile: 2 columns (smaller cards)

## Background Treatment
- Deep navy base with subtle gradient
- Optional: Floating grid lines or subtle aurora effect
- No busy patterns - keep focus on products

## Interactive Elements

### Buttons
- **Primary (CTA)**: Teal gradient background, white text
- **Secondary**: Transparent with teal border
- **Ghost**: Text only with hover background

### Badges/Pills
- Category badges: Solid colored backgrounds
- Status badges: Subtle backgrounds with matching text

## Animations
- Card hover: 300ms ease-out lift + glow
- Button hover: 200ms background transition
- Modal: Fade + scale entrance

## Key Constraints
- Always dark theme (no light mode switching)
- Prices must show both USD and KHR
- Reviews section with verified testimonials
- Trust-building design elements
- Mobile-first responsive approach
