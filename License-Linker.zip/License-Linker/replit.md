# DigiStore - Premium Digital Licenses Catalog

## Overview

DigiStore is a single-page digital product catalog website for selling software licenses and subscriptions. The application features a premium dark-themed design with a blue accent color scheme, displaying products in a grid layout with filtering, search, and shopping cart functionality. Users can browse digital licenses across categories like AI, Streaming, VPN, Productivity, and Design, then add items to a cart for checkout via Telegram support.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight alternative to React Router)
- **State Management**: 
  - React Query (@tanstack/react-query) for server state and API caching
  - React Context for cart state with sessionStorage persistence
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming (dark mode by default)

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript compiled with tsx for development
- **API Pattern**: REST endpoints under `/api/` prefix
- **Build System**: Vite for frontend bundling, esbuild for server bundling

### Data Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Definition**: Shared schema in `shared/schema.ts` using Drizzle's pgTable definitions
- **Validation**: Zod schemas generated from Drizzle schemas via drizzle-zod
- **Current Storage**: In-memory storage implementation (`server/storage.ts`) with hardcoded product data

### Project Structure
```
├── client/           # Frontend React application
│   ├── src/
│   │   ├── components/   # React components including shadcn/ui
│   │   ├── hooks/        # Custom React hooks
│   │   ├── lib/          # Utilities and context providers
│   │   └── pages/        # Page components
├── server/           # Express backend
│   ├── index.ts      # Server entry point
│   ├── routes.ts     # API route definitions
│   ├── storage.ts    # Data access layer
│   └── vite.ts       # Vite dev server integration
├── shared/           # Shared code between client and server
│   └── schema.ts     # Database schema and TypeScript types
```

### Design System
- Dark theme with deep blue (#2563eb) as primary color
- Professional, minimal aesthetic per `design_guidelines.md`
- Inter font family for typography
- Consistent spacing using Tailwind's 4, 6, 8 unit scale

## External Dependencies

### Database
- **PostgreSQL**: Required via `DATABASE_URL` environment variable
- **Drizzle Kit**: Database migrations stored in `/migrations`

### Key NPM Packages
- **@radix-ui/***: Accessible UI primitives for shadcn/ui components
- **@tanstack/react-query**: Async state management
- **drizzle-orm**: Type-safe database ORM
- **express**: HTTP server framework
- **zod**: Runtime type validation

### Build & Development
- **Vite**: Frontend dev server with HMR and production builds
- **esbuild**: Server-side TypeScript bundling
- **Replit plugins**: Development banner and cartographer for Replit environment

### External Services
- **Telegram**: Customer support channel (t.me/digistore_support) - no API integration, just external links