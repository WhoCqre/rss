import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Navbar } from "@/components/navbar";
import { Hero } from "@/components/hero";
import { CategoryBar } from "@/components/category-bar";
import { ProductCatalog } from "@/components/product-catalog";
import { CartDrawer } from "@/components/cart-drawer";
import { Footer } from "@/components/footer";
import type { Product, ProductCategory } from "@shared/schema";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<
    ProductCategory | "all"
  >("all");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");

  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  return (
    <div className="min-h-screen flex flex-col aurora-bg">
      <Navbar searchQuery={searchQuery} onSearchChange={setSearchQuery} />

      <main className="flex-1">
        <Hero />
        <CategoryBar
          selectedCategory={selectedCategory}
          onCategoryChange={setSelectedCategory}
        />
        <ProductCatalog
          products={products}
          isLoading={isLoading}
          searchQuery={searchQuery}
          selectedCategory={selectedCategory}
          sortOrder={sortOrder}
          onCategoryChange={setSelectedCategory}
          onSortChange={setSortOrder}
        />
      </main>

      <Footer />
      <CartDrawer />
    </div>
  );
}
