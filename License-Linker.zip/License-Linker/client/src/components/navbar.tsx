import { ShoppingCart, Search, LogOut, User } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useCart } from "@/lib/cart-context";
import { AuthDialog } from "./auth-dialog";
import { CreditCenter } from "./credit-center";
import { ProfileDialog } from "./profile-dialog";

interface NavbarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

function useAuth() {
  const [user, setUser] = useState<string | null>(() => {
    if (typeof window !== "undefined") {
      return sessionStorage.getItem("telegramUser");
    }
    return null;
  });

  const login = (telegramUsername: string) => {
    sessionStorage.setItem("telegramUser", telegramUsername);
    setUser(telegramUsername);
  };

  const logout = () => {
    sessionStorage.removeItem("telegramUser");
    setUser(null);
  };

  return { user, login, logout };
}

export function Navbar({ searchQuery, onSearchChange }: NavbarProps) {
  const { totalItems, toggleCart } = useCart();
  const { user, login, logout } = useAuth();
  const [showAuthDialog, setShowAuthDialog] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 nav-blur">
        <div className="container mx-auto flex h-16 items-center justify-between gap-4 px-4">
          <div className="flex items-center gap-2">
            <img
              src="/logo.png"
              alt="RSK Digital"
              className="h-10 w-10 object-cover rounded-full border-2 border-primary/30"
            />
            <span className="hidden sm:inline text-xl font-bold tracking-tight" data-testid="text-logo">
              RSK DIGITAL
            </span>
            <span className="text-xs text-muted-foreground ml-1">KH</span>
          </div>

          <div className="hidden md:flex flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="w-full pl-10 bg-card border-border/60 focus-visible:ring-primary/50"
                data-testid="input-search"
              />
            </div>
          </div>

          <div className="flex items-center gap-3">
            <CreditCenter balance={10} />
            <ProfileDialog username={user} creditBalance={10} />
            
            {user ? (
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground hidden sm:inline">
                  @{user}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={logout}
                  title="Logout"
                  data-testid="button-logout"
                >
                  <LogOut className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowAuthDialog(true)}
                className="hidden sm:flex"
                data-testid="button-login"
              >
                <User className="h-4 w-4 mr-2" />
                Login
              </Button>
            )}

            <Button
              variant="ghost"
              size="icon"
              className="relative"
              onClick={toggleCart}
              data-testid="button-cart"
            >
              <ShoppingCart className="h-5 w-5" />
              {totalItems > 0 && (
                <Badge
                  variant="default"
                  className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
                  data-testid="badge-cart-count"
                >
                  {totalItems}
                </Badge>
              )}
            </Button>
          </div>
        </div>

        <div className="md:hidden px-4 pb-3">
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full pl-10 bg-card border-border/60 focus-visible:ring-primary/50"
              data-testid="input-search-mobile"
            />
          </div>
        </div>
      </header>

      <AuthDialog
        isOpen={showAuthDialog}
        onClose={() => setShowAuthDialog(false)}
        onSuccess={(telegramUsername) => {
          login(telegramUsername);
          setShowAuthDialog(false);
        }}
      />
    </>
  );
}
