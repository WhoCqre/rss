import { Zap, Shield, Headphones } from "lucide-react";

const features = [
  {
    icon: Zap,
    title: "Best Prices",
    description: "Get premium software licenses at the most affordable prices in Cambodia",
  },
  {
    icon: Shield,
    title: "Secure & Trusted",
    description: "All transactions are encrypted and verified for your safety",
  },
  {
    icon: Headphones,
    title: "24/7 Support",
    description: "Our support team is always ready to help you via Telegram",
  },
];

export function Hero() {
  return (
    <section className="relative py-16 md:py-24 px-4 overflow-hidden">
      <div className="container mx-auto text-center relative z-10">
        <h1
          className="text-3xl md:text-5xl font-bold leading-tight mb-4 text-slate-100"
          data-testid="text-hero-headline"
        >
          Premium Digital Licenses
          <br />
          <span className="text-teal-400">at Affordable Prices</span>
        </h1>
        <p
          className="text-slate-400 text-lg md:text-xl max-w-2xl mx-auto mb-12"
          data-testid="text-hero-subtext"
        >
          Your trusted source for premium software licenses in Cambodia.
          Best prices with reliable service.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="glass-card rounded-xl p-6 text-center transition-all duration-300 hover:-translate-y-1"
              data-testid={`card-feature-${feature.title.toLowerCase().replace(/\s+/g, "-")}`}
            >
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-teal-500/20 border border-teal-500/30 mb-4">
                <feature.icon className="h-6 w-6 text-teal-400" />
              </div>
              <h3 className="font-semibold text-lg mb-2 text-slate-100">{feature.title}</h3>
              <p className="text-slate-400 text-sm">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
