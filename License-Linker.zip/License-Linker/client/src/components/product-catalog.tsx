import { useMemo } from "react";
import { Filter, ArrowUpDown, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ProductCard } from "@/components/product-card";
import { productCategories, type Product, type ProductCategory } from "@shared/schema";

interface ProductCatalogProps {
  products: Product[];
  isLoading: boolean;
  searchQuery: string;
  selectedCategory: ProductCategory | "all";
  sortOrder: "asc" | "desc";
  onCategoryChange: (category: ProductCategory | "all") => void;
  onSortChange: (order: "asc" | "desc") => void;
}

export function ProductCatalog({
  products,
  isLoading,
  searchQuery,
  selectedCategory,
  sortOrder,
  onCategoryChange,
  onSortChange,
}: ProductCatalogProps) {
  const filteredProducts = useMemo(() => {
    let filtered = [...products];

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (p) =>
          p.name.toLowerCase().includes(query) ||
          p.description.toLowerCase().includes(query) ||
          p.category.toLowerCase().includes(query)
      );
    }

    if (selectedCategory !== "all") {
      filtered = filtered.filter((p) => p.category === selectedCategory);
    }

    filtered.sort((a, b) =>
      sortOrder === "asc" ? a.price - b.price : b.price - a.price
    );

    return filtered;
  }, [products, searchQuery, selectedCategory, sortOrder]);

  return (
    <section className="py-12 px-4" id="products">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8">
          <div>
            <h2
              className="text-2xl md:text-3xl font-bold mb-1"
              data-testid="text-catalog-title"
            >
              Our Products
            </h2>
            <p className="text-muted-foreground">
              Browse our collection of premium digital licenses
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <Select
              value={selectedCategory}
              onValueChange={(value) =>
                onCategoryChange(value as ProductCategory | "all")
              }
            >
              <SelectTrigger
                className="w-[160px] bg-card border-border/60"
                data-testid="select-category"
              >
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {productCategories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select
              value={sortOrder}
              onValueChange={(value) => onSortChange(value as "asc" | "desc")}
            >
              <SelectTrigger
                className="w-[160px] bg-card border-border/60"
                data-testid="select-sort"
              >
                <ArrowUpDown className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="asc">Price: Low to High</SelectItem>
                <SelectItem value="desc">Price: High to Low</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : filteredProducts.length === 0 ? (
          <div
            className="text-center py-24"
            data-testid="text-no-products"
          >
            <p className="text-muted-foreground text-lg">
              No products found matching your criteria
            </p>
            <Button
              variant="ghost"
              className="mt-2 text-primary underline-offset-4 hover:underline"
              onClick={() => {
                onCategoryChange("all");
              }}
              data-testid="button-clear-filters"
            >
              Clear filters
            </Button>
          </div>
        ) : (
          <div
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8"
            data-testid="grid-products"
          >
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}

        <div className="mt-8 text-center text-sm text-muted-foreground">
          Showing {filteredProducts.length} of {products.length} products
        </div>
      </div>
    </section>
  );
}
