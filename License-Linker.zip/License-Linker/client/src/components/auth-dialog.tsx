import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Send, ExternalLink } from "lucide-react";
import { SiTelegram } from "react-icons/si";
import { useToast } from "@/hooks/use-toast";

interface AuthDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (telegramUsername: string) => void;
}

export function AuthDialog({ isOpen, onClose, onSuccess }: AuthDialogProps) {
  const { toast } = useToast();
  const [step, setStep] = useState<"input" | "verify">("input");
  const [telegramUsername, setTelegramUsername] = useState("");
  const [verificationCode, setVerificationCode] = useState("");
  const [sessionId, setSessionId] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isChecking, setIsChecking] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (step === "verify" && sessionId) {
      interval = setInterval(async () => {
        setIsChecking(true);
        try {
          const response = await fetch(`/api/auth/verify/${sessionId}`);
          if (response.ok) {
            const data = await response.json();
            if (data.verified) {
              clearInterval(interval);
              toast({
                title: "Verified!",
                description: `Welcome, @${data.telegramUsername}!`,
              });
              onSuccess(data.telegramUsername);
              handleClose();
            }
          }
        } catch (error) {
        } finally {
          setIsChecking(false);
        }
      }, 3000);
    }
    return () => clearInterval(interval);
  }, [step, sessionId, onSuccess, toast]);

  const handleStartVerification = async () => {
    if (!telegramUsername.trim()) {
      toast({
        title: "Missing Username",
        description: "Please enter your Telegram username",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ telegramUsername: telegramUsername.trim() }),
      });

      const data = await response.json();
      if (data.success) {
        setSessionId(data.sessionId);
        setVerificationCode(data.code);
        setStep("verify");
      } else {
        toast({
          title: "Error",
          description: data.error || "Failed to start verification",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setStep("input");
    setTelegramUsername("");
    setVerificationCode("");
    setSessionId("");
    onClose();
  };

  const openTelegramBot = () => {
    window.open(`https://t.me/rskdigital_bot?start=${verificationCode}`, "_blank");
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <SiTelegram className="h-5 w-5 text-[#0088cc]" />
            {step === "input" ? "Login / Register" : "Verify with Telegram"}
          </DialogTitle>
          <DialogDescription>
            {step === "input"
              ? "Enter your Telegram username to login or create an account."
              : "Send the verification code to our Telegram bot."}
          </DialogDescription>
        </DialogHeader>

        {step === "input" ? (
          <div className="space-y-4">
            <div>
              <Label htmlFor="telegramUsername">Telegram Username</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                  @
                </span>
                <Input
                  id="telegramUsername"
                  placeholder="yourusername"
                  value={telegramUsername.replace("@", "")}
                  onChange={(e) => setTelegramUsername(e.target.value.replace("@", ""))}
                  className="pl-8"
                  data-testid="input-telegram-username"
                />
              </div>
            </div>

            <Button
              onClick={handleStartVerification}
              className="w-full"
              disabled={isLoading}
              data-testid="button-start-verification"
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Continue
                </>
              )}
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-muted/50 border border-border text-center">
              <p className="text-sm text-muted-foreground mb-2">Your verification code:</p>
              <p className="text-3xl font-bold tracking-widest text-primary">
                {verificationCode}
              </p>
            </div>

            <div className="text-center space-y-2">
              <p className="text-sm text-muted-foreground">
                Send this code to our Telegram bot to verify your account:
              </p>
              <Button
                onClick={openTelegramBot}
                className="bg-[#0088cc] hover:bg-[#0077b5]"
                data-testid="button-open-telegram"
              >
                <SiTelegram className="h-4 w-4 mr-2" />
                Open @rskdigital_bot
                <ExternalLink className="h-3 w-3 ml-2" />
              </Button>
            </div>

            <div className="flex items-center justify-center gap-2 py-2">
              {isChecking ? (
                <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
              ) : (
                <div className="h-2 w-2 rounded-full bg-yellow-500 animate-pulse" />
              )}
              <span className="text-sm text-muted-foreground">
                Waiting for verification...
              </span>
            </div>

            <Button
              variant="ghost"
              onClick={handleClose}
              className="w-full"
            >
              Cancel
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
