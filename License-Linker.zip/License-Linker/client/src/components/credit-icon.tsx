interface CreditIconProps {
  className?: string;
  size?: number;
}

export function CreditIcon({ className = "", size = 24 }: CreditIconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <defs>
        <linearGradient id="coinGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#2dd4bf" />
          <stop offset="50%" stopColor="#14b8a6" />
          <stop offset="100%" stopColor="#0d9488" />
        </linearGradient>
        <linearGradient id="innerGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#5eead4" />
          <stop offset="100%" stopColor="#14b8a6" />
        </linearGradient>
        <linearGradient id="shineGradient" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="white" stopOpacity="0.4" />
          <stop offset="100%" stopColor="white" stopOpacity="0" />
        </linearGradient>
      </defs>
      
      <circle cx="24" cy="24" r="22" fill="url(#coinGradient)" stroke="#0d9488" strokeWidth="2" />
      
      <circle cx="24" cy="24" r="17" fill="none" stroke="url(#innerGradient)" strokeWidth="1.5" opacity="0.6" />
      
      <ellipse cx="24" cy="12" rx="14" ry="8" fill="url(#shineGradient)" />
      
      <text
        x="24"
        y="30"
        textAnchor="middle"
        fontSize="20"
        fontWeight="bold"
        fill="white"
        style={{ textShadow: "0 1px 2px rgba(0,0,0,0.3)" }}
      >
        C
      </text>
      
      <circle cx="24" cy="24" r="22" fill="none" stroke="#5eead4" strokeWidth="1" opacity="0.3" />
    </svg>
  );
}
