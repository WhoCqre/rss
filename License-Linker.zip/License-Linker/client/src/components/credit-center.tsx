import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { CreditIcon } from "./credit-icon";
import { Wallet, QrCode, Bitcoin, Clock, ArrowUpRight, ArrowDownLeft } from "lucide-react";

interface CreditCenterProps {
  balance: number;
}

export function CreditCenter({ balance }: CreditCenterProps) {
  const [open, setOpen] = useState(false);

  const topupMethods = [
    {
      id: "khqr",
      name: "KHQR",
      description: "Pay with any Cambodian bank app",
      icon: QrCode,
      status: "soon" as const,
      color: "from-blue-500 to-blue-600",
    },
    {
      id: "crypto",
      name: "Crypto",
      description: "USDT, BTC, ETH and more",
      icon: Bitcoin,
      status: "soon" as const,
      color: "from-orange-500 to-amber-500",
    },
  ];

  const recentTransactions = [
    { type: "topup", amount: 10, date: "Coming soon", description: "KHQR Top-up" },
  ];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10"
          data-testid="button-credit-center"
        >
          <CreditIcon size={20} />
          <span className="font-semibold text-teal-400">{balance.toFixed(2)}</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="glass-card border-white/10 max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3 text-xl">
            <Wallet className="h-6 w-6 text-teal-400" />
            Credit Center
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <Card className="p-6 bg-gradient-to-br from-teal-500/20 to-teal-600/10 border-teal-500/30">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400 mb-1">Available Balance</p>
                <div className="flex items-center gap-3">
                  <CreditIcon size={36} />
                  <span className="text-4xl font-bold text-teal-400" data-testid="text-credit-balance">
                    {balance.toFixed(2)}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-2">$1 = 1 Credit</p>
              </div>
            </div>
          </Card>

          <div>
            <h3 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
              <ArrowUpRight className="h-4 w-4 text-green-400" />
              Top Up Methods
            </h3>
            <div className="space-y-3">
              {topupMethods.map((method) => (
                <Card
                  key={method.id}
                  className="p-4 bg-white/5 border-white/10 hover:bg-white/10 transition-colors cursor-pointer relative overflow-hidden"
                  data-testid={`card-topup-${method.id}`}
                >
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-xl bg-gradient-to-br ${method.color}`}>
                      <method.icon className="h-5 w-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-semibold text-slate-200">{method.name}</h4>
                        <Badge
                          variant="outline"
                          className="text-[10px] px-2 py-0.5 border-amber-500/50 text-amber-400 bg-amber-500/10"
                        >
                          SOON
                        </Badge>
                      </div>
                      <p className="text-sm text-slate-500">{method.description}</p>
                    </div>
                    <Clock className="h-5 w-5 text-slate-600" />
                  </div>
                </Card>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
              <ArrowDownLeft className="h-4 w-4 text-blue-400" />
              Transaction History
            </h3>
            <Card className="p-4 bg-white/5 border-white/10">
              <div className="flex flex-col items-center justify-center py-6 text-center">
                <Clock className="h-10 w-10 text-slate-600 mb-3" />
                <p className="text-slate-400 text-sm">No transactions yet</p>
                <p className="text-slate-600 text-xs mt-1">
                  Your transaction history will appear here
                </p>
              </div>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
