import { Heart, ShoppingCart, Monitor, MessageCircle, Package } from "lucide-react";
import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useCart } from "@/lib/cart-context";
import type { Product } from "@shared/schema";
import {
  SiOpenai,
  SiAnthropic,
  SiNetflix,
  SiNordvpn,
  SiNotion,
  SiAdobe,
  SiCanva,
  SiFigma,
  SiSpotify,
  SiYoutube,
  SiGrammarly,
  SiCoursera,
  SiSkillshare,
  SiBitdefender,
  Si1Password,
  SiGooglecloud,
  SiDropbox,
  SiLinkedin,
} from "react-icons/si";
import { Film, Clapperboard, FileText, MonitorSmartphone } from "lucide-react";
import { type IconType } from "react-icons";

function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash);
}

interface ProductCardProps {
  product: Product;
}

const productIcons: Record<string, { icon: IconType; color: string; bgColor: string }> = {
  "ChatGPT Plus": { icon: SiOpenai, color: "text-white", bgColor: "bg-gradient-to-br from-emerald-400 to-emerald-600" },
  "Claude Pro": { icon: SiAnthropic, color: "text-white", bgColor: "bg-gradient-to-br from-orange-400 to-orange-600" },
  "Netflix Premium": { icon: SiNetflix, color: "text-white", bgColor: "bg-gradient-to-br from-red-500 to-red-700" },
  "Disney+ Premium": { icon: Film as unknown as IconType, color: "text-white", bgColor: "bg-gradient-to-br from-blue-400 to-blue-600" },
  "NordVPN": { icon: SiNordvpn, color: "text-white", bgColor: "bg-gradient-to-br from-blue-500 to-blue-700" },
  "ExpressVPN": { icon: SiNordvpn, color: "text-white", bgColor: "bg-gradient-to-br from-red-400 to-red-600" },
  "Microsoft 365": { icon: FileText as unknown as IconType, color: "text-white", bgColor: "bg-gradient-to-br from-orange-400 to-orange-600" },
  "Notion Pro": { icon: SiNotion, color: "text-white", bgColor: "bg-gradient-to-br from-slate-600 to-slate-800" },
  "Adobe Creative Cloud": { icon: SiAdobe, color: "text-white", bgColor: "bg-gradient-to-br from-red-500 to-red-700" },
  "Canva Pro": { icon: SiCanva, color: "text-white", bgColor: "bg-gradient-to-br from-cyan-400 to-cyan-600" },
  "Figma Professional": { icon: SiFigma, color: "text-white", bgColor: "bg-gradient-to-br from-purple-400 to-purple-600" },
  "Spotify Premium": { icon: SiSpotify, color: "text-white", bgColor: "bg-gradient-to-br from-green-400 to-green-600" },
  "YouTube Premium": { icon: SiYoutube, color: "text-white", bgColor: "bg-gradient-to-br from-red-500 to-red-700" },
  "Grammarly Premium": { icon: SiGrammarly, color: "text-white", bgColor: "bg-gradient-to-br from-green-500 to-green-700" },
  "Coursera Plus": { icon: SiCoursera, color: "text-white", bgColor: "bg-gradient-to-br from-blue-400 to-blue-600" },
  "Skillshare Premium": { icon: SiSkillshare, color: "text-white", bgColor: "bg-gradient-to-br from-green-400 to-green-600" },
  "Bitdefender Total Security": { icon: SiBitdefender, color: "text-white", bgColor: "bg-gradient-to-br from-red-500 to-red-700" },
  "1Password Premium": { icon: Si1Password, color: "text-white", bgColor: "bg-gradient-to-br from-blue-400 to-blue-600" },
  "Google One 2TB": { icon: SiGooglecloud, color: "text-white", bgColor: "bg-gradient-to-br from-blue-400 to-blue-600" },
  "Dropbox Plus": { icon: SiDropbox, color: "text-white", bgColor: "bg-gradient-to-br from-blue-500 to-blue-700" },
  "CapCut Pro": { icon: Clapperboard as unknown as IconType, color: "text-white", bgColor: "bg-gradient-to-br from-slate-700 to-slate-900" },
  "Midjourney Pro": { icon: SiOpenai, color: "text-white", bgColor: "bg-gradient-to-br from-purple-400 to-pink-500" },
  "Windows 11 Pro": { icon: MonitorSmartphone as unknown as IconType, color: "text-white", bgColor: "bg-gradient-to-br from-blue-400 to-blue-600" },
  "LinkedIn Learning": { icon: SiLinkedin, color: "text-white", bgColor: "bg-gradient-to-br from-blue-500 to-blue-700" },
};

const categoryColors: Record<string, string> = {
  "AI": "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
  "Streaming": "bg-red-500/20 text-red-400 border-red-500/30",
  "VPN": "bg-blue-500/20 text-blue-400 border-blue-500/30",
  "Productivity": "bg-orange-500/20 text-orange-400 border-orange-500/30",
  "Design": "bg-purple-500/20 text-purple-400 border-purple-500/30",
  "Cloud": "bg-cyan-500/20 text-cyan-400 border-cyan-500/30",
  "Security": "bg-red-500/20 text-red-400 border-red-500/30",
  "Education": "bg-indigo-500/20 text-indigo-400 border-indigo-500/30",
  "Music": "bg-green-500/20 text-green-400 border-green-500/30",
  "Video": "bg-pink-500/20 text-pink-400 border-pink-500/30",
  "Utilities": "bg-slate-500/20 text-slate-400 border-slate-500/30",
};

const USD_TO_KHR = 4100;

const reviewerNames = [
  "Sokha_Verified",
  "Dara_Premium",
  "Chenda_Pro",
  "Vibol_User",
  "Sopheap_VIP",
  "Rith_Buyer",
  "Kosal_Trusted",
  "Mony_Client",
  "Bopha_Member",
  "Vuthy_Regular",
];

const reviewTexts = [
  "Works perfectly!",
  "Fast delivery!",
  "Excellent service!",
  "Highly recommend!",
  "Great value!",
  "Very satisfied!",
  "Instant access!",
  "Best price!",
  "Trusted seller!",
  "Will buy again!",
];

function generateReviews(productId: string, count: number) {
  const seed = hashString(productId);
  const reviews = [];
  for (let i = 0; i < count; i++) {
    const index = (seed + i) % 10;
    reviews.push({
      username: reviewerNames[index],
      message: reviewTexts[index],
    });
  }
  return reviews;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart();
  const { toast } = useToast();
  const [isLiked, setIsLiked] = useState(false);
  const [showReviews, setShowReviews] = useState(false);

  const iconData = productIcons[product.name];
  const IconComponent = iconData?.icon || Package;
  const iconColor = iconData?.color || "text-white";
  const iconBgColor = iconData?.bgColor || "bg-gradient-to-br from-teal-400 to-teal-600";
  const categoryStyle = categoryColors[product.category] || categoryColors["Utilities"];

  const priceKHR = (product.price * USD_TO_KHR).toLocaleString();
  
  const reviewCount = useMemo(() => {
    const seed = hashString(product.id);
    return (seed % 10) + 1;
  }, [product.id]);
  
  const reviews = useMemo(() => generateReviews(product.id, reviewCount), [product.id, reviewCount]);

  const handleAddToCart = () => {
    addToCart(product);
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart`,
    });
  };

  const handleLike = () => {
    setIsLiked(!isLiked);
  };

  return (
    <div
      className="glass-card glass-card-hover rounded-2xl overflow-hidden transition-all duration-300 hover:-translate-y-1 group"
      data-testid={`card-product-${product.id}`}
    >
      <div className="p-6">
        <div className="flex items-start justify-between mb-5">
          <Badge 
            variant="outline" 
            className={`text-sm font-medium ${categoryStyle} border px-3 py-1`}
          >
            {product.category}
          </Badge>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleLike}
            className="h-10 w-10 rounded-full bg-white/5 hover:bg-white/10"
            data-testid={`button-like-${product.id}`}
          >
            <Heart
              className={`h-5 w-5 transition-colors ${
                isLiked ? "fill-red-500 text-red-500" : "text-slate-400"
              }`}
            />
          </Button>
        </div>

        <div className="flex flex-col items-center py-6">
          {IconComponent && (
            <div
              className={`${iconBgColor} ${iconColor} p-7 rounded-2xl mb-5 shadow-lg group-hover:scale-105 transition-transform duration-300`}
            >
              <IconComponent className="h-14 w-14" />
            </div>
          )}
          <h3
            className="font-semibold text-xl text-slate-100 text-center line-clamp-1 mb-2"
            data-testid={`text-product-name-${product.id}`}
          >
            {product.name}
          </h3>
          <p className="text-base text-slate-400 text-center line-clamp-2 mb-4">
            {product.description}
          </p>
          
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <Monitor className="h-4 w-4" />
            <span>
              {typeof product.devices === "number" 
                ? `${product.devices} ឧបករណ៍` 
                : "គ្មានកំណត់"}
            </span>
          </div>
        </div>

        <div className="border-t border-white/10 pt-5 mt-3">
          <div className="flex items-center justify-between mb-5">
            <div>
              <div className="text-3xl font-bold text-teal-400">
                ${product.price.toFixed(2)}
              </div>
              <div className="text-base text-slate-500">
                ៛{priceKHR}
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowReviews(!showReviews)}
              className="flex items-center gap-2 px-4 py-2 text-sm text-slate-400 hover:text-slate-300 bg-white/5 hover:bg-white/10"
              data-testid={`button-reviews-${product.id}`}
            >
              <MessageCircle className="h-4 w-4" />
              <span>{reviewCount}</span>
            </Button>
          </div>

          <div className="flex gap-3">
            <Button
              variant="ghost"
              size="icon"
              className="h-12 w-12 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-slate-200"
              onClick={handleAddToCart}
              data-testid={`button-add-to-cart-${product.id}`}
            >
              <ShoppingCart className="h-5 w-5" />
            </Button>

            <Button
              onClick={handleAddToCart}
              className="flex-1 py-3 teal-gradient-btn text-white font-semibold rounded-xl text-base shadow-lg shadow-teal-500/20 hover:shadow-teal-500/30"
              data-testid={`button-price-${product.id}`}
            >
              Add to Cart
            </Button>
          </div>
        </div>

        {showReviews && (
          <div className="mt-5 pt-5 border-t border-white/10">
            <div className="text-sm font-medium text-slate-300 mb-4">Verified Reviews</div>
            <div className="space-y-3 max-h-36 overflow-y-auto">
              {reviews.map((review, index) => (
                <div key={index} className="flex items-start gap-3 text-sm bg-white/5 rounded-lg p-3">
                  <span className="font-medium text-teal-400">@{review.username}</span>
                  <span className="text-slate-400">{review.message}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
