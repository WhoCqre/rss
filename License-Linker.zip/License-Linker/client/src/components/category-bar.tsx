import { Button } from "@/components/ui/button";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import type { ProductCategory } from "@shared/schema";
import {
  Sparkles,
  Play,
  Shield,
  Briefcase,
  Palette,
  Music,
  GraduationCap,
  Lock,
  Cloud,
  Video,
  Wrench,
} from "lucide-react";

const categories: { value: ProductCategory | "all"; label: string; icon: typeof Sparkles; color: string }[] = [
  { value: "all", label: "All", icon: Sparkles, color: "bg-primary hover:bg-primary/90 text-primary-foreground" },
  { value: "AI", label: "AI", icon: Sparkles, color: "bg-emerald-600 hover:bg-emerald-700 text-white" },
  { value: "Streaming", label: "Streaming", icon: Play, color: "bg-red-600 hover:bg-red-700 text-white" },
  { value: "VPN", label: "VPN", icon: Shield, color: "bg-blue-600 hover:bg-blue-700 text-white" },
  { value: "Productivity", label: "Productivity", icon: Briefcase, color: "bg-orange-600 hover:bg-orange-700 text-white" },
  { value: "Design", label: "Design", icon: Palette, color: "bg-purple-600 hover:bg-purple-700 text-white" },
  { value: "Music", label: "Music", icon: Music, color: "bg-green-600 hover:bg-green-700 text-white" },
  { value: "Education", label: "Education", icon: GraduationCap, color: "bg-cyan-600 hover:bg-cyan-700 text-white" },
  { value: "Security", label: "Security", icon: Lock, color: "bg-rose-600 hover:bg-rose-700 text-white" },
  { value: "Cloud", label: "Cloud", icon: Cloud, color: "bg-sky-600 hover:bg-sky-700 text-white" },
  { value: "Video", label: "Video", icon: Video, color: "bg-pink-600 hover:bg-pink-700 text-white" },
  { value: "Utilities", label: "Utilities", icon: Wrench, color: "bg-slate-600 hover:bg-slate-700 text-white" },
];

interface CategoryBarProps {
  selectedCategory: ProductCategory | "all";
  onCategoryChange: (category: ProductCategory | "all") => void;
}

export function CategoryBar({ selectedCategory, onCategoryChange }: CategoryBarProps) {
  return (
    <div className="sticky top-16 z-40 bg-background/95 nav-blur border-b border-border/40 py-4">
      <div className="container mx-auto px-4">
        <ScrollArea className="w-full whitespace-nowrap">
          <div className="flex items-center gap-3">
            {categories.map((category) => {
              const Icon = category.icon;
              const isSelected = selectedCategory === category.value;
              return (
                <Button
                  key={category.value}
                  size="default"
                  className={`flex-shrink-0 gap-2 px-5 py-2 text-sm font-medium ${
                    isSelected
                      ? `${category.color} ring-2 ring-white/30 shadow-lg`
                      : `${category.color} opacity-70 hover:opacity-100`
                  }`}
                  onClick={() => onCategoryChange(category.value)}
                  data-testid={`button-category-${category.value}`}
                >
                  <Icon className="h-5 w-5" />
                  {category.label}
                </Button>
              );
            })}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </div>
    </div>
  );
}
