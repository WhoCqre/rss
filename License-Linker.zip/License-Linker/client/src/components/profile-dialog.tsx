import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { User, Package, Clock, CheckCircle, ShoppingBag } from "lucide-react";
import { CreditIcon } from "./credit-icon";

interface PurchaseItem {
  name: string;
  quantity: number;
  price: number;
}

interface Purchase {
  id: string;
  items: PurchaseItem[];
  total: number;
  date: string;
  paymentMethod: "credits" | "telegram";
  status: "completed" | "pending" | "delivered";
}

interface ProfileDialogProps {
  username: string | null;
  creditBalance: number;
}

export function ProfileDialog({ username, creditBalance }: ProfileDialogProps) {
  const [open, setOpen] = useState(false);
  const [purchases, setPurchases] = useState<Purchase[]>([]);

  useEffect(() => {
    const stored = sessionStorage.getItem("purchaseHistory");
    if (stored) {
      setPurchases(JSON.parse(stored));
    }
  }, [open]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
            <CheckCircle className="h-3 w-3 mr-1" />
            Completed
          </Badge>
        );
      case "delivered":
        return (
          <Badge className="bg-teal-500/20 text-teal-400 border-teal-500/30">
            <Package className="h-3 w-3 mr-1" />
            Delivered
          </Badge>
        );
      default:
        return (
          <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
            <Clock className="h-3 w-3 mr-1" />
            Pending
          </Badge>
        );
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full"
          data-testid="button-profile"
        >
          <User className="h-5 w-5" />
        </Button>
      </DialogTrigger>
      <DialogContent className="glass-card border-white/10 max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3 text-xl">
            <User className="h-6 w-6 text-teal-400" />
            My Profile
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <Card className="p-4 bg-gradient-to-br from-slate-800/50 to-slate-900/50 border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400 mb-1">Account</p>
                <p className="text-lg font-semibold text-slate-200">
                  {username ? `@${username}` : "Guest User"}
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm text-slate-400 mb-1">Credit Balance</p>
                <div className="flex items-center gap-2 justify-end">
                  <CreditIcon size={20} />
                  <span className="text-xl font-bold text-teal-400">
                    {creditBalance.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          </Card>

          <div>
            <h3 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
              <ShoppingBag className="h-4 w-4 text-teal-400" />
              Order History
            </h3>

            {purchases.length === 0 ? (
              <Card className="p-6 bg-white/5 border-white/10">
                <div className="flex flex-col items-center justify-center text-center">
                  <Package className="h-12 w-12 text-slate-600 mb-3" />
                  <p className="text-slate-400">No orders yet</p>
                  <p className="text-slate-600 text-sm mt-1">
                    Your purchase history will appear here
                  </p>
                </div>
              </Card>
            ) : (
              <ScrollArea className="h-[300px]">
                <div className="space-y-3 pr-4">
                  {purchases.map((purchase) => (
                    <Card
                      key={purchase.id}
                      className="p-4 bg-white/5 border-white/10"
                      data-testid={`order-${purchase.id}`}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <p className="text-xs text-slate-500">Order #{purchase.id}</p>
                          <p className="text-xs text-slate-600">{purchase.date}</p>
                        </div>
                        {getStatusBadge(purchase.status)}
                      </div>

                      <div className="space-y-1 mb-3">
                        {purchase.items.map((item, idx) => (
                          <div
                            key={idx}
                            className="flex items-center justify-between text-sm"
                          >
                            <span className="text-slate-300">
                              {item.quantity}x {item.name}
                            </span>
                            <span className="text-slate-400">
                              ${(item.price * item.quantity).toFixed(2)}
                            </span>
                          </div>
                        ))}
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-white/10">
                        <div className="flex items-center gap-2">
                          {purchase.paymentMethod === "credits" ? (
                            <>
                              <CreditIcon size={14} />
                              <span className="text-xs text-teal-400">Paid with Credits</span>
                            </>
                          ) : (
                            <span className="text-xs text-slate-500">Via Telegram</span>
                          )}
                        </div>
                        <span className="font-semibold text-teal-400">
                          ${purchase.total.toFixed(2)}
                        </span>
                      </div>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
