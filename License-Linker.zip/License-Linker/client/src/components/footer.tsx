import { SiTelegram, SiFacebook } from "react-icons/si";
import { Button } from "@/components/ui/button";

export function Footer() {
  return (
    <footer className="border-t border-border/40 bg-card/30 py-10 px-4">
      <div className="container mx-auto">
        <div className="flex flex-col items-center text-center gap-6">
          <div className="flex items-center gap-2">
            <img
              src="/logo.png"
              alt="RSK Digital"
              className="h-10 w-10 object-cover rounded-full border-2 border-primary/30"
            />
            <span className="text-lg font-bold" data-testid="text-footer-brand">
              RSK DIGITAL
            </span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <Button
              variant="outline"
              className="border-primary/40 hover:border-primary hover:bg-primary/10"
              onClick={() =>
                window.open("https://t.me/rskdigitals", "_blank")
              }
              data-testid="button-telegram-contact"
            >
              <SiTelegram className="h-4 w-4 mr-2" />
              Contact Us
            </Button>
            <Button
              variant="outline"
              className="border-primary/40 hover:border-primary hover:bg-primary/10"
              onClick={() =>
                window.open("https://t.me/rskdigital", "_blank")
              }
              data-testid="button-telegram-group"
            >
              <SiTelegram className="h-4 w-4 mr-2" />
              Telegram Group
            </Button>
            <Button
              variant="outline"
              className="border-primary/40 hover:border-primary hover:bg-primary/10"
              onClick={() =>
                window.open("https://www.facebook.com/profile.php?id=61585830805943", "_blank")
              }
              data-testid="button-facebook"
            >
              <SiFacebook className="h-4 w-4 mr-2" />
              Facebook Page
            </Button>
          </div>

          <div className="max-w-lg text-sm text-muted-foreground space-y-2">
            <p data-testid="text-disclaimer">
              All product names, logos, and brands are property of their
              respective owners. All company, product and service names used in
              this website are for identification purposes only.
            </p>
            <p>
              Prices and availability are subject to change without notice.
              All sales are final.
            </p>
          </div>

          <div className="text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} RSK DIGITAL. All rights reserved.
          </div>
        </div>
      </div>
    </footer>
  );
}
