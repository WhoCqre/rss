import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, ShoppingBag, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface CartItem {
  product: {
    id: string;
    name: string;
    price: number;
  };
  quantity: number;
}

interface CheckoutDialogProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  totalPrice: number;
  onSuccess: () => void;
}

export function CheckoutDialog({
  isOpen,
  onClose,
  items,
  totalPrice,
  onSuccess,
}: CheckoutDialogProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    bankAccountName: "",
    phoneNumber: "",
    telegramUsername: "",
    remark: "",
  });

  const validateForm = () => {
    if (!formData.bankAccountName.trim() || !formData.phoneNumber.trim() || !formData.telegramUsername.trim()) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return false;
    }
    return true;
  };

  const submitOrder = async () => {
    const orderItems = items.map((item) => ({
      name: item.product.name,
      quantity: item.quantity,
      price: item.product.price,
    }));

    const response = await fetch("/api/order", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        items: orderItems,
        total: totalPrice,
        totalKHR: (totalPrice * 4100).toLocaleString(),
        bankAccountName: formData.bankAccountName,
        phoneNumber: formData.phoneNumber,
        telegramUsername: formData.telegramUsername,
        remark: formData.remark,
      }),
    });

    return await response.json();
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);
    try {
      const result = await submitOrder();
      if (result.orderId) {
        toast({
          title: "Order Submitted!",
          description: `Order ID: ${result.orderId}. We'll contact you on Telegram shortly!`,
        });
        resetForm();
        onSuccess();
        onClose();
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to submit order",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit order. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setFormData({ bankAccountName: "", phoneNumber: "", telegramUsername: "", remark: "" });
  };

  const handleClose = () => {
    if (!isSubmitting) {
      resetForm();
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShoppingBag className="h-5 w-5 text-primary" />
            Checkout
          </DialogTitle>
          <DialogDescription>
            Enter your details to place your order.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmitOrder} className="space-y-4">
          <div className="p-3 rounded-md bg-muted/50 border border-border/40">
            <p className="text-sm text-muted-foreground mb-1">Order Total</p>
            <p className="text-2xl font-bold text-primary">
              ${totalPrice.toFixed(2)}{" "}
              <span className="text-sm text-muted-foreground">
                ({(totalPrice * 4100).toLocaleString()}៛)
              </span>
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {items.length} item{items.length !== 1 ? "s" : ""}:{" "}
              {items.map((i) => i.product.name).join(", ")}
            </p>
          </div>

          <div className="space-y-3">
            <div>
              <Label htmlFor="bankAccountName">
                Bank Account Name <span className="text-destructive">*</span>
              </Label>
              <Input
                id="bankAccountName"
                placeholder="Enter your bank account name"
                value={formData.bankAccountName}
                onChange={(e) =>
                  setFormData({ ...formData, bankAccountName: e.target.value })
                }
                data-testid="input-bank-account"
              />
            </div>

            <div>
              <Label htmlFor="phoneNumber">
                Phone Number <span className="text-destructive">*</span>
              </Label>
              <Input
                id="phoneNumber"
                placeholder="Enter your phone number"
                value={formData.phoneNumber}
                onChange={(e) =>
                  setFormData({ ...formData, phoneNumber: e.target.value })
                }
                data-testid="input-phone"
              />
            </div>

            <div>
              <Label htmlFor="telegramUsername">
                Telegram Username <span className="text-destructive">*</span>
              </Label>
              <Input
                id="telegramUsername"
                placeholder="@yourusername"
                value={formData.telegramUsername}
                onChange={(e) =>
                  setFormData({ ...formData, telegramUsername: e.target.value })
                }
                data-testid="input-telegram"
              />
            </div>

            <div>
              <Label htmlFor="remark">Remark (Optional)</Label>
              <Input
                id="remark"
                placeholder="Any special requests or notes"
                value={formData.remark}
                onChange={(e) =>
                  setFormData({ ...formData, remark: e.target.value })
                }
                data-testid="input-remark"
              />
            </div>
          </div>

          <div className="space-y-2 pt-2">
            <Button
              type="submit"
              className="w-full glow-primary"
              disabled={isSubmitting}
              data-testid="button-submit-order"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Submit Order
                </>
              )}
            </Button>

            <Button
              type="button"
              variant="ghost"
              className="w-full"
              onClick={handleClose}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
