import { X, Trash2, ShoppingBag, CreditCard, Coins } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useCart } from "@/lib/cart-context";
import { CheckoutDialog } from "./checkout-dialog";
import { CreditIcon } from "./credit-icon";
import { useToast } from "@/hooks/use-toast";

export function CartDrawer() {
  const { items, isOpen, closeCart, removeFromCart, clearCart, totalPrice, totalItems } =
    useCart();
  const [showCheckout, setShowCheckout] = useState(false);
  const [creditBalance, setCreditBalance] = useState(10);
  const { toast } = useToast();

  const handleCreditPurchase = () => {
    if (creditBalance >= totalPrice) {
      setCreditBalance(prev => prev - totalPrice);
      
      const orderId = Math.random().toString(36).substring(2, 10).toUpperCase();
      const purchase = {
        id: orderId,
        items: items.map(item => ({
          name: item.product.name,
          quantity: item.quantity,
          price: item.product.price,
        })),
        total: totalPrice,
        date: new Date().toLocaleString("en-US", {
          month: "short",
          day: "numeric",
          year: "numeric",
          hour: "numeric",
          minute: "2-digit",
        }),
        paymentMethod: "credits" as const,
        status: "completed" as const,
      };
      
      const existing = JSON.parse(sessionStorage.getItem("purchaseHistory") || "[]");
      sessionStorage.setItem("purchaseHistory", JSON.stringify([purchase, ...existing]));
      
      toast({
        title: "Purchase Successful!",
        description: `You bought ${totalItems} item(s) for ${totalPrice} credits. Your license keys will be delivered shortly.`,
      });
      clearCart();
      closeCart();
    } else {
      toast({
        title: "Insufficient Credits",
        description: `You need ${totalPrice} credits but only have ${creditBalance}. Please top up your balance.`,
        variant: "destructive",
      });
    }
  };

  if (!isOpen) return null;

  return (
    <>
      <div
        className="fixed inset-0 bg-black/60 z-50 transition-opacity"
        onClick={closeCart}
        data-testid="overlay-cart"
      />

      <div
        className="fixed right-0 top-0 h-full w-full max-w-md bg-card border-l border-border z-50 flex flex-col animate-in slide-in-from-right duration-300"
        data-testid="drawer-cart"
      >
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center gap-2">
            <ShoppingBag className="h-5 w-5 text-primary" />
            <h2 className="text-lg font-semibold">Your Cart</h2>
            <span className="text-sm text-muted-foreground">
              ({totalItems} item{totalItems !== 1 ? "s" : ""})
            </span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={closeCart}
            data-testid="button-close-cart"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-4 p-6">
            <div className="w-16 h-16 rounded-full bg-muted/50 flex items-center justify-center">
              <ShoppingBag className="h-8 w-8 text-muted-foreground" />
            </div>
            <p className="text-muted-foreground" data-testid="text-empty-cart">
              Your cart is empty
            </p>
            <Button
              variant="outline"
              onClick={closeCart}
              data-testid="button-continue-shopping"
            >
              Continue Shopping
            </Button>
          </div>
        ) : (
          <>
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {items.map((item) => (
                  <div
                    key={item.product.id}
                    className="flex items-start gap-4 p-3 rounded-md bg-background/50 border border-border/40"
                    data-testid={`cart-item-${item.product.id}`}
                  >
                    <div className="flex-1 min-w-0">
                      <h4
                        className="font-medium truncate"
                        data-testid={`text-cart-item-name-${item.product.id}`}
                      >
                        {item.product.name}
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {item.product.category}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-sm text-muted-foreground">
                          Qty: {item.quantity}
                        </span>
                        <span className="text-primary font-semibold">
                          ${item.product.price * item.quantity}
                        </span>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground hover:text-destructive"
                      onClick={() => removeFromCart(item.product.id)}
                      data-testid={`button-remove-${item.product.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </ScrollArea>

            <div className="border-t border-border p-4 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Total</span>
                <div className="text-right" data-testid="text-cart-total">
                  <span className="text-2xl font-bold text-primary">${totalPrice}</span>
                  <div className="text-xs text-muted-foreground">{(totalPrice * 4100).toLocaleString()}៛</div>
                </div>
              </div>

              <Separator />

              <div className="p-3 rounded-lg bg-teal-500/10 border border-teal-500/30 mb-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-slate-400">Your Credits</span>
                  <div className="flex items-center gap-2">
                    <CreditIcon size={18} />
                    <span className="font-bold text-teal-400">{creditBalance.toFixed(2)}</span>
                  </div>
                </div>
                {creditBalance >= totalPrice ? (
                  <p className="text-xs text-green-400">You have enough credits for this purchase</p>
                ) : (
                  <p className="text-xs text-amber-400">You need {(totalPrice - creditBalance).toFixed(2)} more credits</p>
                )}
              </div>

              <div className="space-y-2">
                <Button
                  className="w-full teal-gradient-btn text-white font-semibold shadow-lg shadow-teal-500/20"
                  size="lg"
                  onClick={handleCreditPurchase}
                  disabled={creditBalance < totalPrice}
                  data-testid="button-pay-credits"
                >
                  <CreditIcon size={18} className="mr-2" />
                  Pay with Credits ({totalPrice.toFixed(2)})
                </Button>
                <Button
                  variant="outline"
                  className="w-full"
                  size="lg"
                  onClick={() => setShowCheckout(true)}
                  data-testid="button-checkout"
                >
                  <CreditCard className="h-4 w-4 mr-2" />
                  Pay via Telegram
                </Button>
                <Button
                  variant="ghost"
                  className="w-full text-muted-foreground"
                  onClick={clearCart}
                  data-testid="button-clear-cart"
                >
                  Clear Cart
                </Button>
              </div>

              <p className="text-xs text-center text-muted-foreground">
                Credits = instant delivery | Telegram = manual processing
              </p>
            </div>
          </>
        )}
      </div>

      <CheckoutDialog
        isOpen={showCheckout}
        onClose={() => setShowCheckout(false)}
        items={items}
        totalPrice={totalPrice}
        onSuccess={clearCart}
      />
    </>
  );
}
