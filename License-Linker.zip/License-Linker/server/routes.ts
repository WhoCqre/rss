import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { sendTelegramMessageWithButtons, getUpdates, answerCallbackQuery, editMessageText, sendTelegramMessage } from "./telegram";

const OWNER_CHAT_ID = process.env.TELEGRAM_CHAT_ID || "";

interface VerificationSession {
  code: string;
  telegramUsername: string;
  verified: boolean;
  expiresAt: Date;
}

const verificationSessions = new Map<string, VerificationSession>();

interface Order {
  orderId: string;
  status: "pending" | "paid" | "confirmed" | "delivered" | "cancelled";
  items: { name: string; quantity: number; price: number }[];
  total: number;
  totalKHR: string;
  bankAccountName: string;
  phoneNumber: string;
  telegramUsername: string;
  remark?: string;
  createdDate: string;
  messageId?: number;
  chatId?: string;
}

const orders = new Map<string, Order>();

function generateOrderId(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let result = "";
  for (let i = 0; i < 10; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

function getStatusEmoji(status: string): string {
  switch (status) {
    case "pending": return "🟡 Pending Payment";
    case "paid": return "🟢 Paid";
    case "confirmed": return "🔵 Confirmed";
    case "delivered": return "✅ Delivered";
    case "cancelled": return "🔴 Cancelled";
    default: return "🟡 Pending";
  }
}

function buildOrderMessage(order: Order): string {
  const itemsList = order.items
    .map((item) => `• ${item.quantity}× ${item.name} — $${(item.price * item.quantity).toFixed(2)}`)
    .join("\n");

  return `━━━━━━━━━━━━━━━━━━━━
🛒 <b>NEW ORDER</b> #${order.orderId}
━━━━━━━━━━━━━━━━━━━━

<b>Status:</b> ${getStatusEmoji(order.status)}

<b>📋 ORDER DETAILS</b>
${itemsList}

<b>💵 Total:</b> $${order.total.toFixed(2)} (${order.totalKHR}៛)
${order.remark ? `<b>📝 Note:</b> ${order.remark}\n` : ""}
<b>👤 CUSTOMER INFO</b>
• Bank Name: ${order.bankAccountName}
• Phone: ${order.phoneNumber}
• Telegram: ${order.telegramUsername}

<b>📅 Date:</b> ${order.createdDate}
━━━━━━━━━━━━━━━━━━━━`;
}

function buildInlineKeyboard(orderId: string, telegramUsername: string, status: string) {
  const cleanUsername = telegramUsername.replace("@", "");
  
  if (status === "cancelled" || status === "delivered") {
    return {
      inline_keyboard: [
        [
          { text: "📞 Contact", url: `https://t.me/${cleanUsername}` },
        ],
      ],
    };
  }

  return {
    inline_keyboard: [
      [
        { text: "📞 Contact", url: `https://t.me/${cleanUsername}` },
        { text: "🧾 Invoice", callback_data: `invoice_${orderId}` },
      ],
      [
        { text: "✅ Paid", callback_data: `paid_${orderId}` },
        { text: "✅ Confirm", callback_data: `confirm_${orderId}` },
        { text: "📦 Deliver", callback_data: `deliver_${orderId}` },
        { text: "❌ Cancel", callback_data: `cancel_${orderId}` },
      ],
      [
        { text: "🔄 Refresh", callback_data: `refresh_${orderId}` },
      ],
    ],
  };
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get("/api/products", async (_req, res) => {
    const products = await storage.getAllProducts();
    res.json(products);
  });

  app.get("/api/products/:id", async (req, res) => {
    const product = await storage.getProduct(req.params.id);
    if (!product) {
      return res.status(404).json({ error: "Product not found" });
    }
    res.json(product);
  });

  app.post("/api/order", async (req, res) => {
    const { items, total, totalKHR, bankAccountName, phoneNumber, telegramUsername, remark } = req.body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: "Invalid order" });
    }

    if (!bankAccountName || !phoneNumber || !telegramUsername) {
      return res.status(400).json({ error: "Missing customer information" });
    }

    if (!OWNER_CHAT_ID) {
      return res.status(500).json({ error: "Telegram not configured" });
    }

    const orderId = generateOrderId();
    const now = new Date();
    const createdDate = now.toLocaleString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    });

    const order: Order = {
      orderId,
      status: "pending",
      items,
      total,
      totalKHR,
      bankAccountName,
      phoneNumber,
      telegramUsername,
      remark,
      createdDate,
      chatId: OWNER_CHAT_ID,
    };

    orders.set(orderId, order);

    const message = buildOrderMessage(order);
    const keyboard = buildInlineKeyboard(orderId, telegramUsername, "pending");

    const success = await sendTelegramMessageWithButtons(OWNER_CHAT_ID, message, orderId, telegramUsername);

    if (success) {
      res.json({ success: true, orderId, message: "Order sent to Telegram" });
    } else {
      res.status(500).json({ error: "Failed to send order notification" });
    }
  });

  app.post("/api/telegram/webhook", async (req, res) => {
    const update = req.body;

    // Handle verification messages from users
    if (update.message?.text) {
      const text = update.message.text.trim();
      const chatId = update.message.chat.id.toString();
      const username = update.message.from?.username || "";

      // Check if it's a /start command
      if (text === "/start") {
        await sendTelegramMessage(
          chatId,
          `🎉 <b>Welcome to RSK Digital!</b>\n\nTo verify your account, please enter the 6-digit code you received on our website.\n\nIf you don't have a code yet, visit our website and click "Login" to get started.`
        );
        return res.json({ ok: true });
      }

      // Check if it's a 6-digit verification code
      if (/^\d{6}$/.test(text)) {
        const sessionEntries = Array.from(verificationSessions.entries());
        let found = false;
        
        for (const [sessionId, session] of sessionEntries) {
          if (session.code === text && !session.verified) {
            if (new Date() <= session.expiresAt) {
              session.verified = true;
              verificationSessions.set(sessionId, session);
              found = true;
              
              await sendTelegramMessage(
                chatId,
                `✅ <b>Verification Successful!</b>\n\nYour account <b>@${username || session.telegramUsername}</b> has been verified for RSK Digital.\n\nYou can now complete your checkout on our website. Thank you for shopping with us!`
              );
              break;
            }
          }
        }
        
        if (!found) {
          await sendTelegramMessage(
            chatId,
            `❌ <b>Invalid or Expired Code</b>\n\nThe code you entered is either incorrect or has expired.\n\nPlease go back to the website and request a new verification code.`
          );
        }
        
        return res.json({ ok: true });
      }

      // Handle other messages
      await sendTelegramMessage(
        chatId,
        `👋 Hi there!\n\nIf you're trying to verify your account, please enter your 6-digit verification code.\n\nNeed help? Contact our support team.`
      );
      return res.json({ ok: true });
    }

    // Handle callback queries (order buttons)
    if (update.callback_query) {
      const callbackQuery = update.callback_query;
      const data = callbackQuery.data;
      const chatId = callbackQuery.message?.chat?.id?.toString();
      const messageId = callbackQuery.message?.message_id;

      if (!data || !chatId || !messageId) {
        return res.json({ ok: true });
      }

      const [action, orderId] = data.split("_");
      const order = orders.get(orderId);

      if (!order) {
        await answerCallbackQuery(callbackQuery.id, "Order not found");
        return res.json({ ok: true });
      }

      let alertMessage = "";

      switch (action) {
        case "paid":
          order.status = "paid";
          alertMessage = `Order #${orderId} marked as PAID`;
          break;
        case "confirm":
          order.status = "confirmed";
          alertMessage = `Order #${orderId} CONFIRMED`;
          break;
        case "deliver":
          order.status = "delivered";
          alertMessage = `Order #${orderId} marked as DELIVERED`;
          break;
        case "cancel":
          order.status = "cancelled";
          alertMessage = `Order #${orderId} CANCELLED`;
          break;
        case "refresh":
          alertMessage = `Order #${orderId} refreshed`;
          break;
        case "invoice":
          alertMessage = `Invoice for Order #${orderId}\nTotal: $${order.total.toFixed(2)} (${order.totalKHR}៛)`;
          break;
        default:
          alertMessage = "Unknown action";
      }

      orders.set(orderId, order);

      const newMessage = buildOrderMessage(order);
      const newKeyboard = buildInlineKeyboard(orderId, order.telegramUsername, order.status);

      await editMessageText(chatId, messageId, newMessage, newKeyboard);
      await answerCallbackQuery(callbackQuery.id, alertMessage);
    }

    res.json({ ok: true });
  });

  app.get("/api/telegram/chat-id", async (_req, res) => {
    const updates = await getUpdates();
    if (updates && updates.result && updates.result.length > 0) {
      const chatIds = updates.result
        .filter((u: any) => u.message?.chat?.id)
        .map((u: any) => ({
          chatId: u.message.chat.id,
          username: u.message.chat.username || u.message.chat.first_name,
        }));
      res.json({ chatIds });
    } else {
      res.json({ chatIds: [], message: "No messages found. Send a message to your bot first." });
    }
  });

  // User Registration with Telegram Verification
  function generateVerificationCode(): string {
    const chars = "0123456789";
    let result = "";
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  app.post("/api/auth/register", async (req, res) => {
    const { telegramUsername } = req.body;

    if (!telegramUsername) {
      return res.status(400).json({ error: "Telegram username is required" });
    }

    const cleanUsername = telegramUsername.replace("@", "").trim();
    if (!cleanUsername) {
      return res.status(400).json({ error: "Invalid Telegram username" });
    }

    const code = generateVerificationCode();
    const sessionId = `${cleanUsername}_${Date.now()}`;
    
    verificationSessions.set(sessionId, {
      code,
      telegramUsername: cleanUsername,
      verified: false,
      expiresAt: new Date(Date.now() + 10 * 60 * 1000), // 10 minutes
    });

    res.json({
      success: true,
      sessionId,
      code,
      botUsername: "rskdigital_bot",
      message: `Send this code to @rskdigital_bot on Telegram: ${code}`,
    });
  });

  app.get("/api/auth/verify/:sessionId", async (req, res) => {
    const { sessionId } = req.params;
    const session = verificationSessions.get(sessionId);

    if (!session) {
      return res.status(404).json({ error: "Verification session not found" });
    }

    if (new Date() > session.expiresAt) {
      verificationSessions.delete(sessionId);
      return res.status(410).json({ error: "Verification session expired" });
    }

    res.json({
      verified: session.verified,
      telegramUsername: session.telegramUsername,
    });
  });

  app.post("/api/auth/confirm", async (req, res) => {
    const { sessionId, code } = req.body;
    const session = verificationSessions.get(sessionId);

    if (!session) {
      return res.status(404).json({ error: "Verification session not found" });
    }

    if (new Date() > session.expiresAt) {
      verificationSessions.delete(sessionId);
      return res.status(410).json({ error: "Verification session expired" });
    }

    if (session.code !== code) {
      return res.status(400).json({ error: "Invalid verification code" });
    }

    session.verified = true;
    verificationSessions.set(sessionId, session);

    res.json({
      success: true,
      telegramUsername: session.telegramUsername,
    });
  });

  app.get("/api/telegram/setup-webhook", async (_req, res) => {
    const token = process.env.TELEGRAM_BOT_TOKEN;
    const domain = process.env.REPLIT_DEV_DOMAIN || process.env.REPLIT_DOMAINS?.split(",")[0];
    
    if (!token || !domain) {
      return res.status(500).json({ error: "Missing bot token or domain" });
    }

    const webhookUrl = `https://${domain}/api/telegram/webhook`;
    
    try {
      const response = await fetch(`https://api.telegram.org/bot${token}/setWebhook`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: webhookUrl }),
      });
      
      const result = await response.json();
      res.json({ success: true, webhookUrl, result });
    } catch (error) {
      res.status(500).json({ error: "Failed to set webhook" });
    }
  });

  return httpServer;
}
