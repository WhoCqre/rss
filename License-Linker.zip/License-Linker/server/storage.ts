import { type User, type InsertUser, type Product } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
}

const initialProducts: Product[] = [
  {
    id: "1",
    name: "ChatGPT Plus",
    description: "Premium AI assistant with GPT-4 access, faster responses, and priority features",
    category: "AI",
    price: 1,
    devices: 2,
  },
  {
    id: "2",
    name: "Claude Pro",
    description: "Advanced AI assistant with extended context and priority access",
    category: "AI",
    price: 1,
    devices: "Unlimited",
  },
  {
    id: "3",
    name: "Netflix Premium",
    description: "Ultra HD streaming on multiple devices with ad-free entertainment",
    category: "Streaming",
    price: 1,
    devices: 4,
  },
  {
    id: "4",
    name: "Disney+ Premium",
    description: "Access Disney, Marvel, Pixar, Star Wars, and National Geographic content",
    category: "Streaming",
    price: 1,
    devices: 4,
  },
  {
    id: "5",
    name: "NordVPN",
    description: "Fast and secure VPN with servers in 60+ countries",
    category: "VPN",
    price: 1,
    devices: 6,
  },
  {
    id: "6",
    name: "ExpressVPN",
    description: "High-speed VPN with military-grade encryption and 24/7 support",
    category: "VPN",
    price: 1,
    devices: 5,
  },
  {
    id: "7",
    name: "Microsoft 365",
    description: "Complete Office suite with Word, Excel, PowerPoint, and 1TB OneDrive",
    category: "Productivity",
    price: 1,
    devices: 5,
  },
  {
    id: "8",
    name: "Notion Pro",
    description: "All-in-one workspace for notes, docs, wikis, and project management",
    category: "Productivity",
    price: 1,
    devices: "Unlimited",
  },
  {
    id: "9",
    name: "Adobe Creative Cloud",
    description: "Full suite including Photoshop, Illustrator, Premiere Pro, and more",
    category: "Design",
    price: 1,
    devices: 2,
  },
  {
    id: "10",
    name: "Canva Pro",
    description: "Premium design tools with templates, stock media, and Magic Studio AI",
    category: "Design",
    price: 1,
    devices: "Unlimited",
  },
  {
    id: "11",
    name: "Figma Professional",
    description: "Collaborative design tool with unlimited projects and version history",
    category: "Design",
    price: 1,
    devices: "Unlimited",
  },
  {
    id: "12",
    name: "Spotify Premium",
    description: "Ad-free music streaming with offline downloads and HQ audio",
    category: "Music",
    price: 1,
    devices: "Unlimited",
  },
  {
    id: "13",
    name: "YouTube Premium",
    description: "Ad-free YouTube, background play, and YouTube Music included",
    category: "Streaming",
    price: 1,
    devices: "Unlimited",
  },
  {
    id: "14",
    name: "Grammarly Premium",
    description: "Advanced grammar, tone, plagiarism checker, and writing suggestions",
    category: "Productivity",
    price: 1,
    devices: 2,
  },
  {
    id: "15",
    name: "Coursera Plus",
    description: "Unlimited access to 7,000+ courses with certificates",
    category: "Education",
    price: 1,
    devices: 2,
  },
  {
    id: "16",
    name: "Skillshare Premium",
    description: "Thousands of creative classes taught by industry experts",
    category: "Education",
    price: 1,
    devices: "Unlimited",
  },
  {
    id: "17",
    name: "Bitdefender Total Security",
    description: "Complete antivirus protection with VPN and password manager",
    category: "Security",
    price: 1,
    devices: 5,
  },
  {
    id: "18",
    name: "1Password Premium",
    description: "Secure password manager with family sharing and travel mode",
    category: "Security",
    price: 1,
    devices: "Unlimited",
  },
  {
    id: "19",
    name: "Google One 2TB",
    description: "Cloud storage shared across Google services with VPN included",
    category: "Cloud",
    price: 1,
    devices: "Unlimited",
  },
  {
    id: "20",
    name: "Dropbox Plus",
    description: "2TB secure cloud storage with smart sync and remote wipe",
    category: "Cloud",
    price: 1,
    devices: 3,
  },
  {
    id: "21",
    name: "CapCut Pro",
    description: "Professional video editing with filters, effects, and 4K export",
    category: "Video",
    price: 1,
    devices: 2,
  },
  {
    id: "22",
    name: "Midjourney Pro",
    description: "AI image generation with unlimited creative possibilities",
    category: "AI",
    price: 1,
    devices: "Unlimited",
  },
  {
    id: "23",
    name: "Windows 11 Pro",
    description: "Full Windows license with BitLocker and remote desktop",
    category: "Utilities",
    price: 1,
    devices: 1,
  },
  {
    id: "24",
    name: "LinkedIn Learning",
    description: "Access thousands of expert-led courses on business, tech, and creative topics",
    category: "Education",
    price: 1,
    devices: 3,
  },
];

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private products: Map<string, Product>;

  constructor() {
    this.users = new Map();
    this.products = new Map();

    initialProducts.forEach((product) => {
      this.products.set(product.id, product);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.telegramUsername === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      telegramUsername: insertUser.telegramUsername,
      telegramChatId: insertUser.telegramChatId ?? null,
      id,
      verified: false,
      creditBalance: "0",
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }
}

export const storage = new MemStorage();
