const TELEGRAM_API = "https://api.telegram.org/bot";

export async function sendTelegramMessage(chatId: string, message: string): Promise<boolean> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    console.error("TELEGRAM_BOT_TOKEN is not set");
    return false;
  }

  try {
    const response = await fetch(`${TELEGRAM_API}${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: "HTML",
      }),
    });

    if (!response.ok) {
      console.error("Failed to send Telegram message:", await response.text());
      return false;
    }

    return true;
  } catch (error) {
    console.error("Error sending Telegram message:", error);
    return false;
  }
}

export async function sendTelegramMessageWithButtons(
  chatId: string,
  message: string,
  orderId: string,
  telegramUsername: string
): Promise<boolean> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    console.error("TELEGRAM_BOT_TOKEN is not set");
    return false;
  }

  const cleanUsername = telegramUsername.replace("@", "");
  
  const inlineKeyboard = {
    inline_keyboard: [
      [
        { text: "📞 Contact", url: `https://t.me/${cleanUsername}` },
        { text: "🧾 Invoice", callback_data: `invoice_${orderId}` },
      ],
      [
        { text: "✅ Paid", callback_data: `paid_${orderId}` },
        { text: "✅ Confirm", callback_data: `confirm_${orderId}` },
        { text: "📦 Deliver", callback_data: `deliver_${orderId}` },
        { text: "❌ Cancel", callback_data: `cancel_${orderId}` },
      ],
      [
        { text: "🔄 Refresh", callback_data: `refresh_${orderId}` },
      ],
    ],
  };

  try {
    const response = await fetch(`${TELEGRAM_API}${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: "HTML",
        reply_markup: inlineKeyboard,
      }),
    });

    if (!response.ok) {
      console.error("Failed to send Telegram message:", await response.text());
      return false;
    }

    return true;
  } catch (error) {
    console.error("Error sending Telegram message:", error);
    return false;
  }
}

export async function getUpdates(): Promise<any> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    return null;
  }

  try {
    const response = await fetch(`${TELEGRAM_API}${token}/getUpdates`);
    return await response.json();
  } catch (error) {
    console.error("Error getting updates:", error);
    return null;
  }
}

export async function answerCallbackQuery(callbackQueryId: string, text: string): Promise<boolean> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return false;

  try {
    await fetch(`${TELEGRAM_API}${token}/answerCallbackQuery`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        callback_query_id: callbackQueryId,
        text: text,
        show_alert: true,
      }),
    });
    return true;
  } catch (error) {
    console.error("Error answering callback:", error);
    return false;
  }
}

export async function editMessageText(
  chatId: string,
  messageId: number,
  newText: string,
  replyMarkup?: any
): Promise<boolean> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return false;

  try {
    const body: any = {
      chat_id: chatId,
      message_id: messageId,
      text: newText,
      parse_mode: "HTML",
    };
    if (replyMarkup) {
      body.reply_markup = replyMarkup;
    }

    const response = await fetch(`${TELEGRAM_API}${token}/editMessageText`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    return response.ok;
  } catch (error) {
    console.error("Error editing message:", error);
    return false;
  }
}
